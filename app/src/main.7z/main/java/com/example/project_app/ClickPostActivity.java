package com.example.project_app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class ClickPostActivity extends AppCompatActivity {

    private ImageView postImage;
    private TextView postDescription;
    private Button deletePostButton;
    private Button editPostButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_click_post);

        postImage = findViewById(R.id.click_post_image);
        postDescription = findViewById(R.id.click_post_description);
        deletePostButton = findViewById(R.id.click_delete_post_button);
        editPostButton = findViewById(R.id.click_edit_post_button);
    }
}
